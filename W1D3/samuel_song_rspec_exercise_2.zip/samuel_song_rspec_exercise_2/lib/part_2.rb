# 1 -------------------------------------------------
def palindrome?(str)
    (0..str.length - 1).each { |i| return false if str[i] != str[-(i+1)] }
    true
end

# 2 -------------------------------------------------
def substrings(str)
    subs = []
    # i = 0
    # while i < str.length
    #     j = 1
    #     while j <= str[i..-1].length
    #         subs << str[i, j]
    #         j += 1
    #     end
    #     i += 1
    # end
    (0..str.length - 1).each do |start_i|
        (start_i..str.length - 1).each do |start_j|
            subs << str[start_i, str[start_j..-1].length]
        end
    end
    subs
end

# 3 -------------------------------------------------
def palindrome_substrings(str)
    substrings(str).select { |substr| palindrome?(substr) && substr.length > 1 }
end
