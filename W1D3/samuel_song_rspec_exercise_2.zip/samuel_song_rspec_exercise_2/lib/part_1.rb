# 1 -------------------------------------------------
def partition(arr, num)
    lesser = []
    greater = []
    arr.each { |el| el < num ? lesser << el : greater << el }
    [lesser, greater]
end

# 2 -------------------------------------------------
def merge(hash_1, hash_2)
    new_hash = {}
    hash_1.each { |k, v| new_hash[k] = v }
    hash_2.each { |k, v| new_hash[k] = v }
    new_hash
end

# 3 -------------------------------------------------
def censor(sentence, arr)
    new_sent = []
    sentence.split.each { |word| arr.include?(word.downcase) ? new_sent << replace_vowels(word) : new_sent << word }
    new_sent.join(' ')
end

def replace_vowels(word)
    vowels = 'aeiouAEIOU'
    (0..word.length - 1).each { |i| word[i] = '*' if vowels.include?(word[i]) }
    word
end

# 4 -------------------------------------------------
def power_of_two?(num)
    i = num
    while num >= 1
        return true if num == 2 || num == 1
        num /= 2.0
    end
    false
end
