require "byebug"

class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

# PART 1 ------------------------------------------------
  def self.valid_pegs?(chars)
    chars.each { |char| return false if !POSSIBLE_PEGS.has_key?(char.upcase) }
    true
  end

  def initialize(pegs) # pegs = array
    if Code.valid_pegs?(pegs)
      @pegs = pegs.map(&:upcase)
    else
      raise
    end
  end

  def pegs
    @pegs
  end

  def self.random(length)
    Code.new(Array.new(length) { POSSIBLE_PEGS.keys.sample })
  end

  def self.from_string(pegs_string)
    Code.new(pegs_string.split(''))
  end

  def [](index)
    @pegs[index]
  end

  def length
    @pegs.length
  end

# PART 2 ------------------------------------------------
  def num_exact_matches(code_instance)
    match_count = 0
    code_instance.pegs.each_with_index { |peg, i| match_count += 1 if @pegs[i] == peg }
    match_count
  end

  def num_near_matches(code_instance)
    near_match_count = 0
    temp = self.pegs.map { |el| el }
    code_instance.pegs.each_with_index { |peg, i|
      if temp[i] != peg && temp.include?(peg)
        near_match_count += 1
        i_to_remove = temp.index(peg)
        temp.each_with_index { |peg, i| temp[i] = nil if i == i_to_remove }
      end
    }
    near_match_count
  end

  def ==(code_instance)
    self.pegs == code_instance.pegs
  end
end
