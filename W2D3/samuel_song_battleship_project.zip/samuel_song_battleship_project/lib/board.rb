require "byebug"

class Board

    # PART 1 ----------------------------------------------------
    attr_reader :size

    def initialize(n)
        @grid = Array.new(n) { Array.new(n, :N) }
        @size = n * n
    end

    def [](position) # position = [i, j]
        @grid[position[0]][position[1]]
    end

    def []=(position, val) # position = [i, j]
        @grid[position[0]][position[1]] = val
    end

    def num_ships
        @grid.flatten.count { |el| el == :S }
    end

    # PART 2 ----------------------------------------------------
    def attack(position) # position = [i, j]
        if self[position] == :S
            self[position] = :H
            p "you sunk my battleship!"
            true
        else
            self[position] = :X
            false
        end
    end

    def place_random_ships
        until self.num_ships == self.size / 4
            rand_pos = Array.new(2) { rand(0..Math.sqrt(self.size)) }
            if self[rand_pos] != :S
                self[rand_pos] = :S
            end
        end
    end

    def hidden_ships_grid
        new_grid = Array.new(Math.sqrt(self.size)) { Array.new(Math.sqrt(self.size), nil) }
        (0..new_grid.length - 1).each { |i|
            (0..new_grid.length - 1).each { |j|
                position = [i, j]
                new_grid[i][j] = self[position]
            }
        }
        new_grid.each_with_index { |row, i|
            row.each_with_index { |col, j|
                if  new_grid[i][j] == :S
                    new_grid[i][j] = :N
                end
            }
        }
        new_grid
    end

    def self.print_grid(grid)
        grid.each_with_index { |row, i|
            row.each_with_index { |el, j|
                print el
                unless j == row.length - 1
                    print ' '
                end
            }
        puts
        }
    end

    def cheat
        Board.print_grid(@grid)
    end

    def print
        Board.print_grid(hidden_ships_grid)
    end
end
