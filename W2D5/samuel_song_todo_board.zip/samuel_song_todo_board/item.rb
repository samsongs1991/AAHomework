class Item
    attr_reader :deadline, :done
    attr_writer
    attr_accessor :title, :description

    def self.valid_date?(date_string)
        date_arr = date_string.split('-')
        year = date_arr[0].length == 4
        month = date_arr[1].to_i > 0 && date_arr[1].to_i < 13
        day = date_arr[2].to_i > 0 && date_arr[2].to_i < 32
        year && month && day
    end

    def initialize(title, deadline, description='')
        @title = title
        @description = description
        if Item.valid_date?(deadline)
            @deadline = deadline
        else
            raise "Invalid date"
        end
        @done = false
    end

    def deadline=(new_deadline)
        if Item.valid_date?(new_deadline)
            @deadine = new_deadline
        else
            raise "Invalid date"
        end
    end

    def toggle
        @done ? @done = false : @done = true
    end
end
