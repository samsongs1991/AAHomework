require "./item.rb"

require "byebug"
class List
    attr_reader
    attr_writer
    attr_accessor :label

    def initialize(label)
        @label = label
        @items = []
    end

    def add_item(title, deadline, description='')
        debugger
        if Item.valid_date?(deadline)
            @items << Item.new(title, deadline, description)
            true
        else
            false
        end
    end

    def size
        @items.length
    end

    def valid_index?(index)
        index < @items.length && index >= 0
    end

    def swap(i, j)
        if self.valid_index?(i) && self.valid_index?(j)
            @items[i], @items[j] = @items[j], @items[i]
            true
        else
            false
        end
    end

    def [](index)
        if self.valid_index?(index)
            @items[index]
        else
            nil
        end
    end

    def priority
        @items[0]
    end

    def print
        puts "------------------------------------------------------------"
        puts self.label
        puts "------------------------------------------------------------"
        puts "Index | Item                 | Deadline        | Done"
        puts "------------------------------------------------------------"
        num = 0
        @items.each { |item|
            puts "#{num.to_s.ljust(6, ' ')}| #{item.title.ljust(21, ' ')}| #{item.deadline.to_s.ljust(16, ' ')}| #{item.done}"
            num += 1
        }
        puts "------------------------------------------------------------"
    end

    def print_full_item(index)
        puts "------------------------------------------------------------"
        puts "#{@items[index].title.ljust(32, " ")}#{@items[index].deadline}"
        puts "#{@items[index].description.ljust(32, " ")}" + "Done: #{@items[index].done}"
        puts "------------------------------------------------------------"
    end

    def print_priority
        self.print_full_item(0)
    end

    def up(index, amount = 1)
        if !self.valid_index?(index)
            false
        else
            amount.times {
                self.swap(index, index - 1) if index != 0
                index -= 1
            }
            true
        end
    end

    def down(index, amount = 1)
        if !self.valid_index?(index)
            false
        else
            amount.times {
                self.swap(index, index + 1) if index != (self.size - 1)
                index += 1
            }
            true
        end
    end

    def sort_by_date!
        @items.sort_by! { |item| item.deadline }
    end

    def toggle_item(index)
        @items[index].toggle
    end
end
