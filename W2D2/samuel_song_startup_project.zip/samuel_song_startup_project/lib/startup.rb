require "employee"

class Startup
    attr_reader :name, :funding, :salaries, :employees

    def initialize(name, funding, salaries)
        @name = name
        @funding = funding
        @salaries = salaries
        @employees = []
    end

    def valid_title?(title)
        @salaries.has_key?(title)
    end

    def >(other_startup)
        self.funding > other_startup.funding
    end

    def hire(employee_name, title)
        if !self.valid_title?(title)
            raise
        else
            @employees << Employee.new(employee_name, title)
        end
    end

    def size
        @employees.length
    end

    def pay_employee(employee_instance)
        salary = @salaries[employee_instance.title]
        if @funding >= salary
            employee_instance.pay(salary)
            @funding -= salary
        else
            raise
        end
    end

    def payday
        @employees.each { |employee| self.pay_employee(employee) }
    end

    def average_salary
        @employees.inject(0) { |acc, el| acc + @salaries[el.title] } / @employees.length
    end

    def close
        @employees = []
        @funding = 0
    end

    def acquire(other_startup)
        @funding += other_startup.funding
        other_startup.salaries.each { |k, v| @salaries[k] = v if !@salaries.has_key?(k) }
        other_startup.employees.each { |employee| @employees << employee }
        other_startup.close
    end
end
