require_relative "room"

class Hotel
    attr_reader :rooms

    def initialize(name, rooms)
        @name = name
        @rooms = {}
        rooms.each { |room, capacity| @rooms[room] = Room.new(capacity) }
    end

    def name
        @name.split.map { |word| word[0].upcase + word[1..-1].downcase }.join(' ')
    end

    def room_exists?(room_name)
        @rooms.include?(room_name)
    end

    def check_in(person, room)
        if !room_exists?(room)
            puts "sorry, room does not exist"
        else
            if @rooms[room].add_occupant(person)
                puts "check in successful"
            else
                puts "sorry, room is full"
            end
        end
    end

    def has_vacancy?
        vacancy = false
        @rooms.each { |room_name, room_instance| vacancy = true if !room_instance.full? }
        vacancy
    end

    def list_rooms
        @rooms.each { |room_name, room_instance|
            puts room_name + ". " + room_instance.available_space.to_s
        }
    end
end
