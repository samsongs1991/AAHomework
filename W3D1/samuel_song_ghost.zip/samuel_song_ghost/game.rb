require_relative "./player.rb"

require "byebug"

class Game
    attr_reader :dictionary
    attr_writer :fragment

    def initialize(*names)
        file_data = File.open("./dictionary.txt")
        dictionary = Hash.new(nil)
        file_data.read.split("\n").each { |line| dictionary[line] = nil }
        @dictionary = dictionary

        @player_count = names.length

        @record = Hash.new
        @players = Hash.new
        (0..names.length - 1).each do |player_order|
            @players[player_order] = Player.new(names[player_order])
            @record[ @players[player_order] ] = 0
        end

        @current_player = @players[0]

        @fragment = ""
    end

    def next_player!
        @players.each do |order, player|
            if player == @current_player
                @previous_player = @players[order]
                @current_player = @players[(order + 1) % @player_count]
                return true
            end
        end
    end

    def take_turn(player)
        puts @fragment
        puts "Player #{player.name}'s turn. Enter a letter:"
        input = gets.chomp
        until player.alert_invalid_guess(input) && self.valid_play?(input)
            puts "Invalid letter guess. Player '#{player.name}' please try again."
            input = gets.chomp
        end
        @fragment = @fragment + input
    end

    def valid_play?(char)
        temp = @fragment + char
        @dictionary.each { |k, v| return true if k[0...temp.length] == temp }
        false
    end

    def win?
        @dictionary.each { |k, v| return true if k == @fragment }
        false
    end

    def play_round
        @fragment = ""
        until win?
            puts "--------------------------------------------------------------"
            self.take_turn(@current_player)
            self.next_player!
        end
        puts "Player '#{@previous_player.name}' has found the word '#{@fragment}'!"

        @record.each do |player, strikes|
            @record[player] += 1 unless player == @previous_player
        end
    end

    def loser?
        @record.each { |player, strikes| return true if strikes == 5 }
        false
    end

    def find_loser
        @record.each { |player, strikes| return player if strikes == 5 }
    end

    def translate(strikes)
        string = ""
        ghost = "GHOST"
        (0...strikes).each { |idx| string += ghost[idx] }
        string
    end

    def scoreboard
        puts "--------------------------------------------------------------"
        puts "Scoreboard!"
        @record.each do |player, strikes|
            puts "#{player.name}: #{self.translate(strikes)}"
        end
        puts "--------------------------------------------------------------"
    end

    def run
        until loser?
            self.scoreboard
            self.play_round
        end
        @record.delete(self.find_loser)
    end
end
