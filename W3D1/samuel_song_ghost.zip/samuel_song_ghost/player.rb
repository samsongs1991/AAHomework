class Player
    def initialize(name)
        @name = name
    end

    attr_reader :name

    def guess
        input = gets.chomp
        if !self.alert_invalid_guess(input)
            raise "invalid guess"
        end
    end

    def alert_invalid_guess(guess)
        guess.is_a?(String)
    end
end