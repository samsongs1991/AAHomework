class Board
    attr_reader :size
    attr_writer
    attr_accessor

    def initialize(size)
        @size = size
        @grid = Array.new(size) { Array.new(size) }
    end

    def [](pos) # pos = [row, col]
        @grid[ pos[0] ][ pos[1] ]
    end

    def []=(pos, mark)
        @grid[ pos[0] ][ pos[1] ] = mark
    end

    def complete_row?(mark)
        @grid.each { |row| return true if row.all? { |el| el == mark } }
        false
    end

    def complete_col?(mark)
        (0..@grid.length - 1).each { |i| return true if @grid.all? { |row| row[i] == mark } }
        false
    end

    def complete_diag?(mark)
        diag_1 = true
        diag_2 = true

        j = @grid.length - 1
        (0..@grid.length - 1).each { |i|
            diag_1 = false if @grid[i][i] != mark
            diag_2 = false if @grid[i][j] != mark
            j -= 1
        }
        diag_1 || diag_2
    end

    def winner?(mark)
        self.complete_col?(mark) || self.complete_row?(mark) || complete_diag?(mark)
    end

    # This Board#print method is given for free and does not need to be modified
    # It is used to make your game playable.
    def print
        @grid.each { |row| p row }
    end
end
