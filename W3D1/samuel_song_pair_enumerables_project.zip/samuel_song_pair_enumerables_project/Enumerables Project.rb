require 'byebug'

class Array
    def my_each(&prc)
        i = 0
        while i < self.length
            prc.call(self[i])
            i += 1
        end
    end

# return_value = [1, 2, 3].my_each do |num|
#   puts num
# end

# p return_value  # => [1, 2, 3]
    def my_select(&prc)
        new_array = []

        self.my_each{ |el| new_array << el if prc.call(el) }

        new_array
    end
# a = [1, 2, 3]
# p a.my_select { |num| num > 1 } # => [2, 3]
# p a.my_select { |num| num == 4 } # => []
    def my_reject(&prc)
        new_array = []

        self.my_each{ |el| new_array << el unless prc.call(el) }

        new_array
    end

# a = [1, 2, 3]
# p a.my_reject { |num| num > 1 } # => [1]
# p a.my_reject { |num| num == 4 } # => [1, 2, 3]
    def my_any?(&prc)
        self.my_each{ |el| return true if prc.call(el) }
        false
    end

# a = [1, 2, 3]
# p a.my_any? { |num| num > 1 } # => true
# p a.my_any? { |num| num == 4 } # => false
    def my_all?(&prc)
        self.my_each{ |el| return false if !prc.call(el) }
        true        
    end




# a = [1, 2, 3]
# p a.my_all? { |num| num > 1 } # => false
# p a.my_all? { |num| num < 4 } # => true


    # iterate over the array of arrays [1, 2, 3, [4, [5, 6]], [[[7]], 8]]
    # used enumerable within method, that recursively calls the method\
    # base case

    # [] = resulting array
    # as we're iterating through self (array), 
    #   if it's a 1D array (base case), we can concat to the resulting array
    #   else
    #   call my flatten on that el (subarr)



end


class Object
    def my_flatten
        result = []
        if !self.is_a?(Array)
            return [self]        
        end

        self.my_each do |subarr|
            result += subarr.my_flatten
        end

        result
    end
end

# p [1, 2, 3, [4, [5, 6]], [[[7]], 8]].my_flatten # => [1, 2, 3, 4, 5, 6, 7, 8]

class Array
    def my_zip(*args)
        new_arr = []

        (0..self.length - 1).each do |idx|
            temp = [self[idx]]
            args.my_each do |arr|
                # if arr[idx] == nil
                #     temp << nil
                # else
                    temp << arr[idx]
                # end
            end
            new_arr << temp
        end

        new_arr
    end
end

# a = [ 4, 5, 6 ]
# b = [ 7, 8, 9 ]
# p [1, 2, 3].my_zip(a, b) # => [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
# p a.my_zip([1,2], [8])   # => [[4, 1, 8], [5, 2, nil], [6, nil, nil]]
# p [1, 2].my_zip(a, b)    # => [[1, 4, 7], [2, 5, 8]]

# c = [10, 11, 12]
# d = [13, 14, 15]
# p [1, 2].my_zip(a, b, c, d)    # => [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14]]

class Array

    def my_rotate(num=1)
        new_arr = self.clone
        if num > 0
            num.times do
                new_arr = new_arr[1..-1] + [new_arr[0]]
                # temp = new_arr.shift
                # new_arr << temp
            end

        elsif num < 0
            num.abs.times do
                new_arr = [new_arr[-1]] + new_arr[0..-2]
                # temp = new_arr.pop
                # new_arr.unshift(temp)
            end

        elsif num == 0
            return new_arr
        end
        
        new_arr
    end

end

# a = [ "a", "b", "c", "d" ]
# p a.my_rotate         #=> ["b", "c", "d", "a"]
# p a.my_rotate(2)      #=> ["c", "d", "a", "b"]
# p a.my_rotate(-3)     #=> ["b", "c", "d", "a"]
# p a.my_rotate(15)     #=> ["d", "a", "b", "c"]
class Array
    def my_join(str="")
        new_str = ""
        self.my_each { |char| new_str += char + str }

        new_str
    end


    def my_reverse 
        new_arr = []

        i = self.length - 1
        while i >= 0
            char = self[i]
            new_arr << char
            
            i -= 1
        end

        new_arr
    end

end

p [ "a", "b", "c" ].my_reverse   #=> ["c", "b", "a"]
p [ 1 ].my_reverse               #=> [1]

# p a = [ "a", "b", "c", "d" ]
# p a.my_join         # => "abcd"
# p a.my_join("$")    # => "a$b$c$d"