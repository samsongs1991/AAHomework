require "byebug"

class Simon
  COLORS = %w(red blue green yellow)

  attr_accessor :sequence_length, :game_over, :seq

  def initialize
    @sequence_length = 1
    @game_over = false
    @seq = []
  end

  def play
    puts "Let's play a game of Simon says..."
    until self.game_over
      take_turn
    end
    game_over_message
    reset_game
  end

  def take_turn
    show_sequence
    input = require_sequence

    if input != seq
      self.game_over = true
    end

    if self.game_over == false
      round_success_message
      self.sequence_length += 1
      sleep(2)
    end
  end

  def show_sequence
    add_random_color
    seq.each_with_index do |color, i|
      if i == seq.length - 1
        print color
        sleep(2)
      else
        print color + " - "
        sleep(2)
      end
    end
    sleep(2)
    system("clear")
  end

  def require_sequence
    puts "Input the sequence => i.e. yellow blue red red"
    input = nil
    input = gets.chomp.split
  end

  def add_random_color
    seq << COLORS.sample
  end

  def round_success_message
    puts "You got it! Let's kick it up a notch."
  end

  def game_over_message
    puts "Wah wah wah. Better luck next time"
    puts "Your streak: #{self.sequence_length}"
  end

  def reset_game
    self.sequence_length = 1
    self.game_over = false
    self.seq = []
  end
end


a = Simon.new
a.play
