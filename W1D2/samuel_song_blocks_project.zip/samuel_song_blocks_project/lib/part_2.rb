# 1 --------------------------------------------------
def all_words_capitalized?(words)
    words.all? { |word| word[0] == word[0].upcase && word[1..-1] == word[1..-1].downcase }
end

# 2 --------------------------------------------------
def no_valid_url?(urls)
    tlds = ['com', 'net', 'io', 'org']
    urls.none? { |url| tlds.include?(url.split('.')[1]) }
end

# 3 --------------------------------------------------
def any_passing_students?(students)
    students.any? { |student| get_avg(student[:grades]) >= 75 }
end

def get_avg(grades)
    grades.sum.to_f / grades.length
end
