# 1---------------------------------------------------
def hipsterfy(word)
    vowels = 'aeiou'
    last_i = nil
    (0..word.length - 1).each { |i| last_i = i if vowels.include?(word[i]) }
    return word if last_i == nil
    word[last_i] = ''
    word
end

# 2---------------------------------------------------
def vowel_counts(str)
    vowels = 'aeiouAEIOU'
    count = Hash.new(0)
    str.each_char { |char| count[char.downcase] += 1 if vowels.include?(char) }
    count
end

# 3---------------------------------------------------
# iterate through str
#     find the char's idx in alpha
#     concat the new char to new str

def caesar_cipher(str, num)
    new_str = ''
    alpha = 'abcdefghijklmnopqrstuvwxyz'
    str.each_char { |char|
        if !alpha.include?(char)
            new_str += char
        else
            new_char = alpha[(alpha.index(char) + num) % alpha.length]
            new_str += new_char
        end
    }
    new_str
end
