# 1---------------------------------------------------
def average(num_1, num_2)
    (num_1 + num_2) / 2.0
end

# 2---------------------------------------------------
def average_array(nums)
    nums.sum.to_f / nums.length
end

# 3---------------------------------------------------
def repeat(str, num)
    str * num
end

# 4---------------------------------------------------
def yell(str)
    str.upcase + '!'
end

# 5---------------------------------------------------
def alternating_case(sentence)
    sentence.split.each_with_index { |word, i| i % 2 == 0 ? word.upcase! : word.downcase! }.join(' ')
end
