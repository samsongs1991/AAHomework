# 1 --------------------------------------------------------
def reverser(str, &prc)
    prc.call(str.reverse)
end

# 2 --------------------------------------------------------
def word_changer(sentence, &prc)
    new_sent = []
    sentence.split.each { |word| new_sent << prc.call(word) }
    new_sent.join(' ')
end

# 3 --------------------------------------------------------
def greater_proc_value(num, prc_1, prc_2)
    prc_1.call(num) > prc_2.call(num) ? prc_1.call(num) : prc_2.call(num)
end

# 4 --------------------------------------------------------
def and_selector(arr, prc_1, prc_2)
    new_arr = []
    arr.each { |el| new_arr << el if prc_1.call(el) && prc_2.call(el) }
    new_arr
end

# 5 --------------------------------------------------------
def alternating_mapper(arr, prc_1, prc_2)
    new_arr = []
    arr.each_with_index { |el, i| i % 2 == 0 ? new_arr << prc_1.call(el) : new_arr << prc_2.call(el) }
    new_arr
end
