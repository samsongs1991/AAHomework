# 1 --------------------------------------------------------
def my_map(arr, &prc)
    new_arr = []
    arr.each { |el| new_arr << prc.call(el) }
    new_arr
end

# 2 --------------------------------------------------------
def my_select(arr, &prc)
    new_arr = []
    arr.each { |el| new_arr << el if prc.call(el) }
    new_arr
end

# 3 --------------------------------------------------------
def my_count(arr, &prc)
    count = 0
    arr.each { |el| count += 1 if prc.call(el) }
    count
end

# 4 --------------------------------------------------------
def my_any?(arr, &prc)
    arr.each { |el| return true if prc.call(el) }
    false
end

# 5 --------------------------------------------------------
def my_all?(arr, &prc)
    arr.each { |el| return false if !prc.call(el) }
    true
end

# 6 --------------------------------------------------------
def my_none?(arr, &prc)
    arr.each { |el| return false if prc.call(el) }
    true
end
