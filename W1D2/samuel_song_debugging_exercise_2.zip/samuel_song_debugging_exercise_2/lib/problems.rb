# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

require "byebug"

# 1---------------------------------------------------------
def largest_prime_factor(num)
    largest_p_f = 1
    (1..num).each { |divisor| largest_p_f = divisor if num % divisor == 0 && is_prime?(divisor) }
    largest_p_f
end

def is_prime?(num)
    return false if num < 2
    (2...num).each { |divisor| return false if num % divisor == 0 }
    true
end

# 2----------------------------------------------------------
def unique_chars?(str)
    char_count = Hash.new(0)
    str.each_char { |char| char_count[char] += 1 }
    !char_count.any? { |k, v| v > 1 }
end

# 3----------------------------------------------------------
def dupe_indices(arr)
    dups = Hash.new(0)
    arr.each { |el| dups[el] += 1 }
    dups.delete_if { |k, v| v < 2 }

    dups_idx = {}
    dups.each_key { |k| dups_idx[k] = indexes(arr, k) }
    dups_idx
end

def indexes(arr, char)
    indices = []
    arr.each_with_index { |el, i| indices << i if el == char }
    indices
end

# 4----------------------------------------------------------
def ana_array(arr_1, arr_2)
    hash_1 = Hash.new(0)
    hash_2 = Hash.new(0)

    arr_1.each { |el| hash_1[el] += 1 }
    arr_2.each { |el| hash_2[el] += 1 }

    hash_1 == hash_2
end
