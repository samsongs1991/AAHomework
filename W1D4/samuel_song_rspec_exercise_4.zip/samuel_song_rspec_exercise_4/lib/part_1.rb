# 1 ----------------------------------------------------
def my_reject(arr, &prc)
    arr.select { |el| !prc.call(el) }
end

# 2 ----------------------------------------------------
def my_one?(arr, &prc)
    count = 0
    arr.each { |el| count += 1 if prc.call(el) }
    count == 1 ? true : false
end

# 3 ----------------------------------------------------
def hash_select(hash, &prc)
    new_hash = {}
    hash.each { |k, v| new_hash[k] = v if prc.call(k, v) }
    new_hash
end

# 4 ----------------------------------------------------
def xor_select(arr, prc_1, prc_2)
    new_arr = []
    arr.each { |el| new_arr << el if (prc_1.call(el) || prc_2.call(el)) && !(prc_1.call(el) && prc_2.call(el)) }
    new_arr
end

# 5 ----------------------------------------------------
def proc_count(val, procs)
    count = 0
    procs.each { |prc| count += 1 if prc.call(val) }
    count
end
