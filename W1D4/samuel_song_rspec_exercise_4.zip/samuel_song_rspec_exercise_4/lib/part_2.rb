# 1 ----------------------------------------------------
def proper_factors(num)
    (1...num).select { |divisor| num % divisor == 0 }
end

# 2 ----------------------------------------------------
def aliquot_sum(num)
    proper_factors(num).sum
end

# 3 ----------------------------------------------------
def perfect_number?(num)
    num == aliquot_sum(num) ? true : false
end

# 4 ----------------------------------------------------
def ideal_numbers(n)
    arr = []
    i = 1
    until arr.length == n
        arr << i if perfect_number?(i)
        i += 1
    end
    arr
end
