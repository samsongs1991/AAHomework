# 1 -------------------------------------------------
def element_count(arr)
    hash = Hash.new(0)
    arr.each { |el| hash[el] += 1 }
    hash
end

# 2 -------------------------------------------------
def char_replace!(str, hash)
    (0..str.length - 1).each { |i| str[i] = hash[str[i]] if hash.include?(str[i]) }
    str
end

# 3 -------------------------------------------------
def product_inject(nums)
    nums.inject { |acc, el| acc * el }
end
