# 1 -------------------------------------------------
def is_prime?(num)
    return false if num < 2
    (2...num).each { |divisor| return false if num % divisor == 0 }
    true
end

# 2 -------------------------------------------------
def nth_prime(n)
    n_prime = nil
    counter = 0
    i = 0
    while counter < n
        if is_prime?(i)
            counter += 1
            n_prime = i
        end
        i += 1
    end
    n_prime
end

# 3 -------------------------------------------------
def prime_range(min, max)
    (min..max).select { |num| is_prime?(num) }
end
