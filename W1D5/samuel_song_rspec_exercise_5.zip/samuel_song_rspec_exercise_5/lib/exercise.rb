# 1 ---------------------------------------------------------
def zip(*arrs)
    final = []
    temp = []
    i = 0
    arrs[0].length.times do
        arrs.each { |arr| temp << arr[i] }
        final << temp
        temp = []
        i += 1
    end
    final
end

# 2 ---------------------------------------------------------
def prizz_proc(arr, prc_1, prc_2)
    arr.select { |el| (prc_1.call(el) || prc_2.call(el)) && !(prc_1.call(el) && prc_2.call(el)) }
end

# 3 ---------------------------------------------------------
def zany_zip(*arrs)
    long = longest_arr_length(arrs)

    final = []
    temp = []
    i = 0
    long.times do
        arrs.each { |arr| i >= arr.length ? temp << nil : temp << arr[i] }
        final << temp
        temp = []
        i += 1
    end
    final
end

def longest_arr_length(arrs)
    long = 0
    arrs.each { |arr| long = arr.length if arr.length > long }
    long
end

# 4 ---------------------------------------------------------
def maximum(arr, &prc)
    return nil if arr.length == 0
    big = arr[0]
    arr.each { |el| big = el if prc.call(el) >= prc.call(big) }
    big
end

# 5 ---------------------------------------------------------
def my_group_by(arr, &prc)
    hash = Hash.new { |h, k| h[k] = [] }
    arr.each { |el| hash[prc.call(el)] << el }
    hash
end

# 6 ---------------------------------------------------------
def max_tie_breaker(arr, prc, &blk)
    arr.inject do |acc, el|
        if blk.call(el) > blk.call(acc)
            el
        elsif blk.call(el) == blk.call(acc)
            prc.call(el) > prc.call(acc) ? el : acc
        else
            acc
        end
    end
end

# 7 ---------------------------------------------------------
def silly_syllables(sent)
    sent.split.map { |word| vowel_count(word) > 1 ? remove_silly_letters(word) : word }.join(' ')
end

def remove_silly_letters(word)
    vowels = 'aeiouAEIOU'
    first_v = first_vowel(word)
    last_v = last_vowel(word)
    word[first_v..last_v]
end

def first_vowel(word)
    vowels = 'aeiouAEIOU'
    (0..word.length - 1).each { |i| return i if vowels.include?(word[i]) }
end

def last_vowel(word)
    vowels = 'aeiouAEIOU'
    (word.length - 1).downto(0) { |i| return i if vowels.include?(word[i]) }
end

def vowel_count(word)
    vowels = 'aeiouAEIOU'
    count = 0
    word.each_char { |char| count += 1 if vowels.include?(char) }
    count
end
