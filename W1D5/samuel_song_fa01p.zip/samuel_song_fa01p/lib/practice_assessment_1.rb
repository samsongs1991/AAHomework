# 1 ---------------------------------------------------
def first_letter_vowel_count(sent)
    vowels = 'aeiouAEIOU'
    count = 0
    sent.split.each { |word| count += 1 if vowels.include?(word[0]) }
    count
end

# 2 ---------------------------------------------------
def count_true(arr, prc)
    count = 0
    arr.each { |el| count += 1 if prc.call(el) }
    count
end

# 3 ---------------------------------------------------
def procformation(arr, prc_1, prc_2, prc_3)
    arr.map { |el| prc_1.call(el) ? prc_2.call(el) : prc_3.call(el) }
end

# 4 ---------------------------------------------------
def array_of_array_sum(arr_of_nums)
    arr_of_nums.flatten.sum
end

# 5 ---------------------------------------------------
def selective_reverse(sent)
    vowels = 'aeiouAEIOU'
    sent.split.map { |word| vowels.include?(word[0]) || vowels.include?(word[-1]) ? word : word.reverse }.join(' ')
end

# 6 ---------------------------------------------------
def hash_missing_keys(hash, *args)
    not_keys = []
    args.each { |el| not_keys << el if !hash.include?(el) }
    not_keys
end
