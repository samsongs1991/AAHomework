class Bootcamp

# PART 1 -------------------------------------------------------------------

  def initialize(name, slogan, student_capacity)
    @name = name # string
    @slogan = slogan # string
    @student_capacity = student_capacity # number
    @teachers = []
    @students = []
    @grades = Hash.new { |h, k| h[k] = [] }
  end

  def name
    @name
  end

  def slogan
    @slogan
  end

  def teachers
    @teachers
  end

  def students
    @students
  end

  def hire(teacher)
    @teachers << teacher
  end

  def enroll(student)
    if @students.length < @student_capacity
        @students << student
        true
    else
        false
    end
  end

  def enrolled?(student)
    @students.include?(student)
  end

  # PART 2 -------------------------------------------------------------------

  def student_to_teacher_ratio
    @students.length / @teachers.length
  end

  def add_grade(student, grade)
    if @students.include?(student)
        @grades[student] << grade
        true
    else
        false
    end
  end

  def num_grades(student)
    @grades[student].length
  end

  def average_grade(student)
    return nil if @grades[student].length == 0 || !@students.include?(student)
    @grades[student].sum / @grades[student].length
  end
end
