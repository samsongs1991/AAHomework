class Array

# PART 1 ------------------------------------------------
  def span
    return nil if self.length == 0

    contains_nums = true
    self.each { |el| contains_nums = false if !el.is_a?(Integer) }
    self.max - self.min if contains_nums
  end

  def average
    return nil if self.length == 0

    contains_nums = true
    self.each { |el| contains_nums = false if !el.is_a?(Integer) }
    self.sum / self.length.to_f if contains_nums
  end

  def median
    return nil if self.length == 0

    if self.length.even?
        mid_1 = (self.length / 2) - 1
        mid_2 = self.length / 2
        return (self.sort[mid_1] + self.sort[mid_2]) / 2.0
    else
        mid = self.length / 2
        return self.sort[mid]
    end
  end

  def counts
    hash = Hash.new(0)
    self.each { |el| hash[el] += 1 }
    hash
  end

# PART 2 ------------------------------------------------
  def my_count(arg)
    self.counts[arg]
  end

  def my_index(arg)
    (0..self.length - 1).each { |i| return i if self[i] == arg }
    nil
  end

  def my_uniq
    new_arr = []
    self.each { |el| new_arr << el if !new_arr.include?(el) }
    new_arr
  end

  def my_transpose
    transposed = Array.new(self.length) { Array.new(self[0].length) }
    (0..self[0].length - 1).each { |i|
        (0..self.length - 1).each { |j|
            transposed[i][j] = self[j][i]
        }
    }
    transposed
  end
end
