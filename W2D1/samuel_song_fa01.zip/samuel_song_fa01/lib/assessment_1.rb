# 1 -------------------------------------------------
def string_map!(str, &prc)
    str.each_char.with_index { |char, i| str[i] = prc.call(char) }
end

# 2 -------------------------------------------------
def three?(arr, &prc)
    arr.count { |el| prc.call(el) } == 3
end

# 3 -------------------------------------------------
def nand_select(arr, prc_1, prc_2)
    arr.reject { |el| prc_1.call(el) && prc_2.call(el) }
end

# 4 -------------------------------------------------
def hash_of_array_sum(hash)
    total_sum = 0
    hash.each { |k, v| total_sum += hash[k].sum }
    total_sum
end

# 5 -------------------------------------------------
def abbreviate(sent)
    sent.split.map { |word| word.length > 4 ? remove_v(word) : word }.join(' ')
end

def remove_v(word)
    vowels = 'aeiouAEIOU'
    new_word = ''
    word.each_char { |char| new_word += char if !vowels.include?(char) }
    new_word
end

# 6 -------------------------------------------------
def hash_selector(hash, *args)
    return hash if args.length == 0
    new_hash = {}
    args.each { |k| new_hash[k] = hash[k] if hash.has_key?(k) }
    new_hash
end
