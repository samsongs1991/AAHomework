class Array
  # Write an `Array#my_inject` method. If my_inject receives no argument, then
  # use the first element of the array as the default accumulator.
  # **Do NOT use the built-in `Array#inject` or `Array#reduce` methods in your
  # implementation.**

  def my_inject(accumulator = nil, &prc)
    if accumulator == nil
      accumulator = self[0]
      (1...self.length).each do |i|
        accumulator = prc.call(self[i])
      end
    else
      (0...self.length).each do |i|
        accumulator = prc.call(self[i])
      end
    end
  end
end

# Define a method `primes(num)` that returns an array of the first "num" primes.
# You may wish to use an `is_prime?` helper method.

def is_prime?(num)
  return false if num < 2
  (2...num).each { |divisor| return false if num % divisor == 0 }
  true
end

def primes(num)
  arr = []
  i = 0
  until arr.length == num
    arr << i if is_prime?(i)
    i += 1
  end
  arr
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

# 1, 1, 2, 6, 24
def factorials_rec(num)
  return [] if num <= 0
  return [1] if num == 1
  return [1, 1] if num == 2


  result = factorials_rec(num-1)

  fact = result.length * num

  result += result + fact
end

class Array
  # Write an `Array#dups` method that will return a hash containing the indices
  # of all duplicate elements. The keys are the duplicate elements; the values
  # are arrays of their indices in ascending order, e.g.
  # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    hash = Hash.new { |h, k| h[k] = [] }
    self.each_with_index do |el, i|
      hash[el] << i
    end
    hash.delete_if { |k, v| v.length < 2 }
  end
end

class String
  # Write a `String#symmetric_substrings` method that returns an array of
  # substrings that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
  # Only include substrings of length > 1.

  def symmetric_substrings
    arr = []
    (0..self.length - 1).each do |i|
      (i..self.length - 1).each do |j|
        substr = self[i..j]
        arr << substr if symmetric?(substr) && substr.length > 1
      end
    end
    arr
  end

  def symmetric?(str)
    str == str.reverse
  end
end

class Array
  # Write an `Array#merge_sort` method; it should not modify the original array.
  # **Do NOT use the built in `Array#sort` or `Array#sort_by` methods in your
  # implementation.**

  def merge_sort(&prc)
    mid = self.length / 2
    left = self[0...mid]
    right = self[mid..-1]

    merge_sort
  end

  private
  def self.merge(left, right, &prc)

  end
end
